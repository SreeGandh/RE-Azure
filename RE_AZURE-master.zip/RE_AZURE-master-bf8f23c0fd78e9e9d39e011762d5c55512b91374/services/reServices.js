const constants = require('../constants/constants')
const mongo_utils = require('../utils/mongoUtils')
const showroom_model = require('../models/showroom')
const invoice_model = require('../models/invoiceModel')
const RE_unified_Schema = require('../models/unifiedInvoice')
const csvtojson = require("csvtojson")


createShowRoom = async(city, state, address, contact) => {
    response = {}
    try{
        let new_showroom = {
            city : city,
            state : state,
            address : address,
            contact : contact,
            is_active : true
        }

        insert_result = await mongo_utils.insert(showroom_model, new_showroom)
        if(insert_result === null){
            throw new error("cannot insert document")
        }
        response = {
            isSuccess : true,
            code : constants.SUCCESS_CODES[1],
            data : insert_result
        }
    }
    catch(err){
        response = {
            isSuccess : false ,
            code : constants.ERROR_CODES[8]
        }
    }
    return response
}

getShowroom =  async(id) => {

    let find_filter = {showroom_code : id}
    let find_result = await mongo_utils.findOne(showroom_model, find_filter)
    if(find_result === null || find_result.is_active === false){
        response = {
            isSuccess : false,
            code : constants.ERROR_CODES[4],
            data : []
        }
    }else{
        response = {
            isSuccess : true,
            code : constants.SUCCESS_CODES[6],
            data : find_result
        }
    }

    return response
}

updateShowroom = async(id ,update_param) => {

    let find_filter = {showroom_code : id}
    let find_result = await mongo_utils.findOne(showroom_model, find_filter)

    if(find_result === null || find_result.is_active === false){
        response = {
            isSuccess : false,
            code : constants.ERROR_CODES[4],
            data : []
        }
    }else {
        let filter_query = {
            showroom_code : id
        }
        let update_query = {
            $set : update_param
        }
        let update_result = await mongo_utils.findOneAndUpdate(showroom_model, filter_query, update_query)
    
        if(update_result === null){
            response = {
                isSuccess : false,
                code : constants.ERROR_CODES[2],
                data : []
            }
        }else{
            response = {
                isSuccess : true,
                code : constants.SUCCESS_CODES[2],
                data : update_result
            }
        }    
    }

    return response
}

deleteShowroom = async(id) => {

    let find_filter = {showroom_code : id}
    let find_result = await mongo_utils.findOne(showroom_model, find_filter)

    if(find_result === null || find_result.is_active === false){
        response = {
            isSuccess : false,
            code : constants.ERROR_CODES[4],
            data : []
        }
        
    }else{
        let filter_query = {
            showroom_code : id
        }
        let delete_query = {
            $set : {
                is_active : false
            }
        }
    
        let update_result = await mongo_utils.findOneAndUpdate(showroom_model, filter_query, delete_query)
    
        if(update_result === null){
            response = {
                isSuccess : false,
                code : constants.ERROR_CODES[3],
                data : []
            }
        }else{
            response = {
                isSuccess : true,
                code : constants.SUCCESS_CODES[5],
                data : "Showroom deleted successfully"
            }
        }
    }
    return response
}


createInvoice = async (document) => {

    try{
        // document.id = short.generate()
        insert_result = await mongo_utils.insert(invoice_model, document)
        response = {
            isSuccess : true,
            code : constants.SUCCESS_CODES[3],
            data : insert_result
        }
    }
    catch(err){
        response = {
            isSuccess : false,
            code : constants.ERROR_CODES[5]
        }
    }
    return response 
}

getInvoice = async(id) => {
    let find_filter = {id : id}
    let find_result = await mongo_utils.findOne(invoice_model, find_filter)
    if(find_result === null){
        response = {
            isSuccess : false,
            code : constants.ERROR_CODES[8],
            data : []
        }
    }else{
        response = {
            isSuccess : true,
            code : constants.SUCCESS_CODES[6],
            data : find_result
        }
    }

    return response
}

updateInvoice = async(id ,update_param) => {


    let filter_query = {
        id : id
    }
    let update_query = {
        $set : update_param
    }
    let find_result = await mongo_utils.findOneAndUpdate(invoice_model, filter_query, update_query)

    if(find_result === null){
        response = {
            isSuccess : false,
            code : constants.ERROR_CODES[6],
            data : []
        }
    }else{
        response = {
            isSuccess : true,
            code : constants.SUCCESS_CODES[4],
            data : find_result
        }
    }

    return response
}


getInvoices = async (resultCount, page, sortField, sortOrder) => {
    // let invoicesResult = await invoice_model.find()
    //                            .sort([[sortField, sortOrder == constants.ASCENDING ? 1 : -1]])
    //                            .skip(parseInt((page-1)*resultCount))
    //                            .limit(parseInt(resultCount))

    let invoicesResult = await invoice_model.aggregate([
        {
          $skip: parseInt((page-1)*resultCount),
        },
        {
            $limit: parseInt(resultCount, 10),
        },
        {
          $sort: {
            [sortField]: sortOrder == constants.ASCENDING ? 1 : -1,
          },
        }
      ]);


    if(invoicesResult === null){
        response = {
            isSuccess : false,
            code : constants.ERROR_CODES[9],
            data : []
        }
    }else{
        response = {
            isSuccess : true,
            code : constants.SUCCESS_CODES[7],
            data : invoicesResult
        }
    }
    return response
}

writeInvoices = async(file, context) => {
    try{
        let data = file[0].data.toString()
        context.log("file", file)
        context.log("data", data)
        let csvData = await csvtojson().fromString(data)
        context.log("csvData",csvData)
        result = await mongo_utils.insertMany(invoice_model, csvData)
        response = {
            isSuccess : true,
            code : constants.SUCCESS_CODES[8],
            data : result
        }
    }catch(err){
        response = {
            isSuccess : false,
            code : constants.ERROR_CODES[8],
            data : []
        }
    }

    return response
}


backupOperation = async(context) => {
    context.log("backup operation started")
    let clearDb = mongo_utils.deleteMany(RE_unified_Schema,{})
    let lookupResult = await showroom_model.aggregate([
        {
            $lookup : {
                from : "invoices",
                localField : "showroom_code",
                foreignField : "showroom_code",
                as : "orders"
            }
        }
    ])

    let response = await insertMany(RE_unified_Schema, lookupResult)
    context.log("backup operation completed")
}

// (async() => {
//     await this.backupOperation()
// })();


bikesPendingForRegistration = async(id) => {
    await backupOperation()
    let result = await invoice_model.aggregate([
        {
            $match : { "$and" :[
                {showroom_code : id}, {registration_no : {$exists: false}}
            ]},
        },
        {
            $group :{
                _id : "$model",
                count : {
                    $sum : 1
                }
            }
        },
        {
            $project : {
                _id : 0,
                modelName : "$_id",
                count : 1 
            }
        }
    ])
    // console.log(result)
    return result
}

turnoverPerShowroom = async(month, year) => {

    startDate = new Date()
    startDate.setFullYear(year,month-1,1)

    if (month-2 < 0){
        month = 11
        year = year
    }else{
        month -=2
        year+=1
    }

    endDate = new Date()
    endDate.setFullYear(year,month,31)

    // console.log(startDate, endDate)

    let result = await RE_unified_Schema.aggregate([
        {
            $unwind : "$orders"
        },
        {
            $project : {
                showroomCode : "$showroom_code",
                cost : "$orders.cost",
                date : "$orders.date_of_billing"
            }
        },
        {
            $match :{
                $and  :[
                    {date : {"$gte" : startDate}},
                    {date : {"$lte" : endDate}}
                ]
            }
        },   
        {
            $group: {
                _id : "$showroomCode",
                turnover : {$sum : "$cost"},
            }
        },
        {
            $project : {
                showroomName : "$_id",
                _id : 0,
                turnover : 1
            }
        }
    ])
    // console.log(result)
    return result
}

invoicesPendingForAMonth = async(showroomCode, context) => {

    let result = await invoice_model.aggregate([
        {
            $match : {
                "$and" :[
                    {showroom_code : showroomCode}, {payment_status : constants.PENDING}
                ]
            }
        },

        {
           $project : {
               invoiceID : "$_id",
               showroomCode : "$showroom_code",
               paymentStatus : "$payment_status",
               billedDate : "$date_of_billing",
               pendingFor : {$trunc :
                                 [{$divide : 
                                    [{$subtract : [new Date(), "$date_of_billing"]},60*60*24*1000]},0]},
               _id : 0
           } 
        },
        {
            $match : {
                pendingFor : {"$gt" : 30}
            }
        }
    ])

    // console.log(result)
    return result
}

colorBasedSales = async(startMonth,startYear,endMonth,endYear,showroomCode) => {
    startDate = new Date()
    startDate.setFullYear(startYear, startMonth-1, 1)

    endDate = new Date()
    endDate.setFullYear(endYear, endMonth-1,31)

    // console.log(startDate , endDate)

    let result = await invoice_model.aggregate([
        {
            $match : {
                showroom_code : showroomCode
            }
        },
        {
            $project : {
                id : "$id",
                model : "$model",
                color : "$color",
                cost : "$cost",
                date : "$date_of_billing"
            }
        },
        {
            $match : {
                $and  :[
                    {date : {"$gte" : startDate}},
                    {date : {"$lte" : endDate}}
                ]
            }
        },
        {
            $group :{
                _id : "$color",
                count : {$sum : 1}                
            }
        },
        {
            $project : {
                color : "$_id",
                _id : 0,
                count : 1
            }
        },      
        {
            $sort :{
                count : -1
            }
        }
    ])
    // console.log(result)
    return result


}

noOfBikesSold = async(sortOrder,startMonth,startYear,endMonth,endYear,limit) => {

    startDate = new Date()
    startDate.setFullYear(startYear, startMonth-1, 1)

    endDate = new Date()
    endDate.setFullYear(endYear, endMonth-1,31)

    let result = await RE_unified_Schema.aggregate([
        {
            $unwind : "$orders"
        },
        {
            $project : {
                showroomCode : "$showroom_code",
                year : {$year : "$orders.date_of_billing"},
                cost : "$orders.cost",
                model : "$orders.model",
                date : "$orders.date_of_billing"
            }
        },
        {
            $match : {
                $and  :[
                    {date : {"$gte" : startDate}},
                    {date : {"$lte" : endDate}}
                ]
            }
        },
        {
            $group: {
                _id : "$showroomCode",
                bikesSold : {$sum : 1},
            }
        },
        {
            $project : {
                showroomName : "$_id",
                _id : 0,
                bikesSold : 1
            }
        },
        {
            $sort : {
                bikesSold : sortOrder
            } 
        },
        {
            $limit : limit
        }
    ])
    // console.log(result)
    return result
}

// noOfBikesSoldInAMonth(-1,6,2020,1)



registrationNoForInsurance = async(showroomCode) => {
    let result = await invoice_model.aggregate([
        {
            $match : {
                showroom_code : showroomCode
            }
        },
        {
           $project : {
               invoiceID : "$_id",
               showroomCode : "$showroom_code",
               registrationNo : "$registration_no",
               billedDate : "$date_of_billing",
               DaysAfterLastInsuranceRenewal : {$trunc :
                                 [{$divide : 
                                    [{$subtract : [new Date(), "$date_of_billing"]},60*60*24*1000]},0]},
               _id : 0
           } 
        },
        {
            $match : {
                DaysAfterLastInsuranceRenewal : {"$gte" : 365}
            }
        },
        {
            $sort : {
                DaysAfterLastInsuranceRenewal : -1
            }
        }
    ])

    // console.log(result)
    return result
}

modelsBasedOnRevenue = async() => {
    let result = await invoice_model.aggregate([
        {
            $group :{
                _id : "$model",
                revenue : {
                    $sum : "$cost"
                }
            }
        },
        {
            $sort : {
                revenue : -1
            }
        },
        {
            $project : {
                _id : 0,
                modelName : "$_id",
                revenue : 1
            }
        }
    ])
    // console.log(result)
    return result
}

bikeModelsBasedOnPopularity = async() => {
    let result = await invoice_model.aggregate([
        {
            $group :{
                _id : "$model",
                count : {
                    $sum : 1
                }
            }
        },
        {
            $sort : {
                count : -1
            }
        },
        {
            $project : {
                _id : 0,
                modelName : "$_id"
            }
        }
    ])
    // console.log(result)
    return result
}




module.exports = {
    createShowRoom,
    getShowroom,
    updateShowroom,
    deleteShowroom,
    createInvoice,
    getInvoice,
    getInvoices,
    updateInvoice,
    writeInvoices,
    bikesPendingForRegistration,
    turnoverPerShowroom,
    invoicesPendingForAMonth,
    colorBasedSales,
    noOfBikesSold,
    registrationNoForInsurance,
    bikeModelsBasedOnPopularity,
    modelsBasedOnRevenue,
    backupOperation
}