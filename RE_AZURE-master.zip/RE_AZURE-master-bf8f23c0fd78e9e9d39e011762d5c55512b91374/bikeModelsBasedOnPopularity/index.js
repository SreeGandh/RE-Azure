const services = require('../services/reServices')
const constants = require('../constants/constants')

module.exports = async function (context, req) {

    let statusCode = 200
    let response = {}
    try{
        let result = await services.bikeModelsBasedOnPopularity()
        response = {
            isSuccess : "true",
            code : constants.SUCCESS_CODES[9],
            data : result
        }
    }
    catch(err){
        statusCode = 400
        response = {
            isSuccess :"false",
            code : constants.ERROR_CODES[8],
            data : []
        }
    }

    context.res = {
        status : statusCode,
        body : response
    }

};