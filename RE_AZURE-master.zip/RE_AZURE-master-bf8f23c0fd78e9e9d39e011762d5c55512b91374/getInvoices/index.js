const services = require('../services/reServices')
const constants = require('../constants/constants')

module.exports = async function (context, req) {
    let status_code = 200
    let response = {}
    let resultCount = req.query.count || constants.RESULTS_PER_PAGE
    let page = req.query.page || 1
    let sortField = req.query.sortField || null
    let sortOrder = req.query.sortOrder || constants.ASCENDING
    context.log("resultCount" , resultCount)
    context.log("page", page)
    context.log("sortField", sortField)
    context.log("sortOrder",sortOrder)
    response = await services.getInvoices(resultCount, page, sortField, sortOrder)

    context.log("response", response)
    context.res = {
        status : status_code,
        body : response
    }
};