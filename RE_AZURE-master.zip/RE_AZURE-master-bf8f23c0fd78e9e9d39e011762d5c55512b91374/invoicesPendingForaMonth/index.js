const services = require('../services/reServices')
const constants = require('../constants/constants')

module.exports = async function (context, req) {
    
    let statusCode = 200
    let response = {}
    try{
        logTrace('invoices pending Start')
        id = context.bindingData.id
        context.log("binding id", id)
        let result = await services.invoicesPendingForAMonth(id,context)
        context.log(result)
        response = {
            isSuccess : "true",
            code : constants.SUCCESS_CODES[9],
            data : result
        }
    }
    catch(err){
        statusCode = 400
        response = {
            isSuccess :"false",
            code : constants.ERROR_CODES[8],
            data : []
        }
    }

    context.res = {
        status : statusCode,
        body : response
    }

};