const helpers = require('../utils/helpers')
const services = require('../services/reServices')
const constants = require('../constants/constants')

module.exports = async function (context, req) {

    let statusCode = 200
    let response = {}
    try{
        let month = 4
        let year = req.query.year || helpers.getCurrentYear()
        let result = await services.turnoverPerShowroom(parseInt(month), parseInt(year))
        response = {
            isSuccess : "true",
            code : constants.SUCCESS_CODES[9],
            data : result
        }
    }
    catch(err){
        statusCode = 400
        response = {
            isSuccess :"false",
            code : constants.ERROR_CODES[8],
            data : []
        }
    }

    context.res = {
        status : statusCode,
        body : response
    }

};