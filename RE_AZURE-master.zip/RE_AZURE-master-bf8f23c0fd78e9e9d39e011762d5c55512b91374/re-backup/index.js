const services = require('../services/reServices')

module.exports = async function (context, myTimer) {
    var timeStamp = new Date().toISOString();
    
    if (myTimer.isPastDue)
    {
        context.log('JavaScript is running late!');
    }
    await services.backupOperation(context)
    context.log('JavaScript timer trigger function ran!', timeStamp);   
};