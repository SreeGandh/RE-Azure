const mongoose = require('mongoose')
const short = require('shortid')

const showroom_schema = mongoose.Schema({
    showroom_code : {
        type : String,
        default : short.generate,
        required : true
    },
    city : {
        type : String,
        required : true
    },
    state : {
        type : String,
        required : true
    },
    address : {
        type : String,
        required : true
    },
    contact : {
        type : String,
        required : true
    },
    is_active : {
        type : Boolean, 
        required : true
    }
})


module.exports =  mongoose.model('RE_HQ',showroom_schema)
