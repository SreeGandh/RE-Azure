const mongoose = require('mongoose')
const short = require('shortid')
const constants = require('../constants/constants')

const invoice_schema = mongoose.Schema({
    id : {
        type : String,
        default : short.generate,
        required : true
    },
    showroom_code : {
        type : String,
        required : true
    },
    model :{
        type : String,
        required : true
    },
    cost :{
        type : Number,
        required : true
    },
    color :{
        type : String,
        enum : constants.BIKE_COLORS,
        required : true
    },
    date_of_billing : {
        type : Date,
        default : Date.now,
        required : true
    },
    payment_status : {
        type : String,
        enum : constants.PAYMENT_STATUS,
        required : true
    },
    payment_mode : {
        type : String,
        enum : constants.PAYMENT_MODES,
        required : true
    },
    sold_date : {
        type : Date,
        default : null
    },
    engine_no : {
        type : String
    },
    chasis_no : {
        type : String
    },
    registration_no :{
        type : String
    }
})

module.exports = mongoose.model('invoice', invoice_schema);