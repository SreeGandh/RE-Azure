const mongoose = require('mongoose')
const constants = require('../constants/constants')

const RE_Unified_Schema = mongoose.Schema({
    showroom_code : {
        type : String,
        required : true
    },
    city : {
        type : String,
        required : true
    },
    state : {
        type : String,
        required : true
    },
    address : {
        type : String,
        required : true
    },
    contact : {
        type : String,
        required : true
    },
    is_active : {
        type : Boolean, 
        required : true
    },
    orders : [
        {
            id : {
                type : String,
                required : true
            },
            showroom_code : {
                type : String,
                required : true
            },
            model :{
                type : String,
                required : true
            },
            cost :{
                type : Number,
                required : true
            },
            color :{
                type : String,
                enum : constants.BIKE_COLORS,
                required : true
            },
            date_of_billing : {
                type : Date,
                default : Date.now,
                required : true
            },
            payment_status : {
                type : String,
                enum : constants.PAYMENT_STATUS,
                required : true
            },
            payment_mode : {
                type : String,
                enum : constants.PAYMENT_MODES,
                required : true
            },
            sold_date : {
                type : Date,
                default : null
            },
            engine_no : {
                type : String
            },
            chasis_no : {
                type : String
            },
            registration_no :{
                type : String
            } 
        }
    ]
})


module.exports =  mongoose.model('RE_Unified',RE_Unified_Schema)