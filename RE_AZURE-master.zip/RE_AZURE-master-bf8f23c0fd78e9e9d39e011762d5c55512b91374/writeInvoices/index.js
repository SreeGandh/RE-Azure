const multipart = require("parse-multipart")
const services = require('../services/reServices')
const constants = require('../constants/constants')

module.exports = async function (context, request){

    status_code = 200
    response = {}

    var bodyBuffer = Buffer.from(request.body);
    var boundary = multipart.getBoundary(request.headers['content-type']);
    var parts = multipart.Parse(bodyBuffer, boundary);
    context.log("parts" ,parts)
    context.log("data1", parts[0].data)
    if (!(parts[0].data)) {
        status_code = 400
        response = {
            isSuccess : false,
            code : constants.ERROR_CODES[10],
            data : []
        }
     }else{
         response = await services.writeInvoices(parts, context)
     }

    context.res = {
        status : status_code,
        body : response
    }
    context.done();
    // context.res = { body : {status : 200, name : parts[0].filename, type: parts[0].type, data: parts[0].data.length}}; 
    // context.done();  

};