const services = require('../services/reServices')
const constants = require('../constants/constants')
const helpers = require('../utils/helpers')

module.exports = async function (context, req) {
    let statusCode = 200
    let response = {}
    try{
        id = context.bindingData.id
        period = req.query.period || "year"
        let result = []
        if(period === "month"){
            startMonth = req.query.month|| 1
            startYear = req.query.year || helpers.getCurrentYear()
            endMonth = startMonth
            endYear = startYear
            
        }else if(period === "quarter"){
            startMonth = req.query.month || 1
            startYear = req.query.year || helpers.getCurrentYear()
            endMonth = parseInt(startMonth)+2
            endYear = parseInt(startYear)
            if(endMonth > 12){
                endMonth -= 12
                endYear += 1
            }

            // console.log(startMonth , startYear)
            // console.log(endMonth, endYear)

           
        }else if(period === "year"){
            startMonth = req.query.month|| 1
            startYear = req.query.year || helpers.getCurrentYear()
            endMonth = parseInt(startMonth)+11
            endYear = parseInt(startYear)
            if(endMonth > 12){
                endMonth -= 12
                endYear += 1
            }
        }

        result = await services.colorBasedSales(startMonth, startYear, endMonth, endYear, id)

        response = {
            isSuccess : "true",
            code : constants.SUCCESS_CODES[9],
            data : result
        }
    }
    catch(err){
        statusCode = 400
        response = {
            isSuccess :"false",
            code : constants.ERROR_CODES[8],
            data : []
        }
    }

    context.res = {
        status : statusCode,
        body : response
    }
};