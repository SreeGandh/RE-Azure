var mongoose = require('mongoose');

const { DefaultAzureCredential } = require("@azure/identity");
const { SecretClient } = require("@azure/keyvault-secrets");

const dotenv = require('dotenv')
// dotenv.config({path:'../.env'})
dotenv.config()

// console.log(process.env.AZURE_TENANT_ID)
// console.log(process.env.AZURE_CLIENT_ID)
// console.log(process.env.AZURE_CLIENT_SECRET)



connectToDb = async() => {
    const connectionString = await connectToKeyVault()
    console.log("connectionString",connectionString)
    mongoose.connect(connectionString, 
    {
  auth: {
    user: process.env.COSMODDB_USER,
    password: process.env.COSMOSDB_PASSWORD
  },
   useNewUrlParser: true , useUnifiedTopology: true, useFindAndModify: false,
   retryWrites: false}
   )
   .then(() => {
       console.log('Connection to CosmosDB successful')
       })
   .catch((err) => console.error(err));   
};

connectToKeyVault = async() => {

    const credential = new DefaultAzureCredential();

    const vaultName = "re-azure";
    const url = `https://${vaultName}.vault.azure.net`;

    const client = new SecretClient(url, credential);

    // await putSecret(client);
    const secretName = "conectionString"

    return await getSecret(client, secretName)

}

// putSecret = async(client) => {
//   const secretName = "conectionString"
//   const conectionString = "mongodb://re-azure:0FGCyjsbOu6CM3CP9W2FuO5yWi2h6V9weXwt8EqJi7GfPMoof5Pobe62NiVyAGPOX7iFEMAZH3gTMREEUrbNZQ==@re-azure.mongo.cosmos.azure.com:10255/?ssl=true&appName=@re-azure@"
//   const result = await client.setSecret(secretName, conectionString);
//   console.log(result)
// }


getSecret = async(client, secretName) => {
  const secret = await client.getSecret(secretName)
  console.log(secret.value)
  return secret.value
}


findOne = async(model, filtervalue) => {
  let result = await model.findOne(filtervalue)
 // console.log("find one res", result)
  return result
}

findOneAndUpdate = async (model, filter_query, update_query) => {
  let result = await model.findOneAndUpdate(filter_query, update_query,{
      new : true
  })
 // console.log("update one ", result)
  return result 
}

insert = async (model, document) => {
  let result = await new model(document).save()
  //console.log("insert", result)
  return result
}

bulkWrite  = async(model, documentJsonArray, orderedValue) => {
  let result = await model.bulkWrite(documentJsonArray , { ordered : orderedValue})
  return result
}

insertMany = async(model, documentJsonArray) => {
 // console.log(documentJsonArray)
  let result = await model.insertMany(documentJsonArray)
  // .then(() => {
  //     console.log("data inserted")
  // }).catch(function(err) {
  //     console.log(err)
  // })
  return result
}

deleteMany = async(model, filterValue) => {
  let result = await model.deleteMany(filterValue)
  console.log(result)
  return result
}

(async() => {
  console.log("self calling func")
  await connectToDb().then(() => {
    console.log("function called and db connected")
  })
})();

module.exports ={
  findOne,
  findOneAndUpdate,
  insert,
  bulkWrite,
  insertMany,
  deleteMany
}

