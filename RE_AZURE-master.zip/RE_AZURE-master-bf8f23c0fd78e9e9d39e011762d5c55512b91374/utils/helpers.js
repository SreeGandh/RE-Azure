getCurrentYear = () => {
    currentDate = new Date(Date.now())
    currentYear = currentDate.getFullYear()
    return currentYear
}

module.exports = {
   getCurrentYear
}