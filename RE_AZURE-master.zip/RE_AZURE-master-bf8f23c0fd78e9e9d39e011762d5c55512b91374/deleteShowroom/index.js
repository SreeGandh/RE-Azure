const services = require('../services/reServices')
const constants = require('../constants/constants')

module.exports = async function (context, req) {
    let response = {}
    let status_code = 200

    try{
        let showroom_id = context.bindingData.id
        response = await services.deleteShowroom(showroom_id)
        if(response.isSuccess === false){
            status_code = 400
        }
    }
    catch(err){
        response = {
            isSuccess : false,
            code :  constants.ERROR_CODES[8],
            data : []
        }
        status_code = 400
    }

    context.res = {
        status : status_code,
        body : response
    }
};