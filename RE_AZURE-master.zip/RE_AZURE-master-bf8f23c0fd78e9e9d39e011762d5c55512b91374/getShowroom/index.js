const services = require('../services/reServices')
const constants = require('../constants/constants')

module.exports = async function (context, req) {
    let status_code = 200 
    let response = {}

    try{
        let showroom_code = context.bindingData.id
        response = await services.getShowroom(showroom_code)
        if(response.isSuccess === false){
            status_code = 404
        }
    }
    catch(err){
        response = {
            isSuccess : false,
            code :  constants.ERROR_CODES[8],
            data : []
        }
        status_code = 400
    }

    context.res = {
        status : status_code,
        body : response
    }

};