const services = require('../services/reServices')
const constants = require('../constants/constants')

module.exports = async function (context, req) {
    // context.log('JavaScript HTTP trigger function processed a request.');

   

    // if (context.bindingData.name ||req.query.name || (req.body && req.body.name)) {
    //     context.res = {
    //         // status: 200, /* Defaults to 200 */
    //         body: "Hello " + (context.bindingData.name ||req.query.name || req.body.name)
    //     };
    // }
    // else {
    //     context.res = {
    //         status: 400,
    //         body: "Please pass a name on the query string or in the request body"
    //     };
    // }

    let status_code = 200 
    let showroom_details = req.body
    let response = {}
    context.log("showroom detail",showroom_details)
    try{
        if (!(showroom_details.city &&
            showroom_details.state &&
            showroom_details.address &&
            showroom_details.contact)){
              throw new error("Details missing")
        }else{
            response = await services.createShowRoom(showroom_details.city,
                                    showroom_details.state,
                                    showroom_details.address,
                                    showroom_details.contact)
        }
    }
    catch (err){
        response = {
            isSuccess : false,
            code :  constants.ERROR_CODES[1]
        }
        status_code = 400
    }

    if(response.isSuccess === false){
        status_code = 400
    }
    // resp.status(status_code).send(response)
    context.res = {
        status : status_code,
        body : response
    }

};