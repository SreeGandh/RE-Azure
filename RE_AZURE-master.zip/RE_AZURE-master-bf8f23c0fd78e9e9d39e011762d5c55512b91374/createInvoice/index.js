const services = require('../services/reServices')
const constants = require('../constants/constants')

module.exports = async function (context, req) {
    
    let status_code = 200 
    let invoice_details = req.body
    let response = {}
    try{
        if (!(invoice_details.model &&
            invoice_details.payment_status &&
            invoice_details.payment_mode && 
            invoice_details.showroom_code &&
            invoice_details.cost &&
            invoice_details.color)){
              throw new error("Details missing")
        }else{
            document = {
                model_id : invoice_details.model_id,
                payment_status : invoice_details.payment_status,
                payment_mode : invoice_details.payment_mode,
                showroom_code : invoice_details.showroom_code,
                model : invoice_details.model,
                cost : invoice_details.cost,
                color : invoice_details.color
            }
            response = await services.createInvoice(document)
        }
    }
    catch (err){
        response = {
            isSuccess : false,
            code :  constants.ERROR_CODES[5]
        }
        status_code = 400
    }

    if(response.isSuccess === false){
        status_code = 400
    }
    
    context.res = {
        status : status_code,
        body : response
    }

};